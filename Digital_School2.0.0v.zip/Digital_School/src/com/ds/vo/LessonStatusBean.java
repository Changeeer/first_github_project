package com.ds.vo;



public class LessonStatusBean{

	
	private Integer id;
	private String lesson1;
	private String lesson2;
	private String lesson3;
	private String lesson4;
	private String lesson5;
	private String lesson6;
	private String lesson7;
	private String lesson8;
	private String lesson9;
	private String lesson10;
	private String lesson11;
	private String lesson12;
	private String lesson13;
	private String lesson14;
	private String lesson15;
	private String lesson16;
	private String lesson17;
	private String lesson18;
	private String lesson19;
	private String lesson20;
	private String lesson21;
	private String lesson22;
	public LessonStatusBean(Integer id, String lesson1, String lesson2,
			String lesson3, String lesson4, String lesson5, String lesson6,
			String lesson7, String lesson8, String lesson9, String lesson10,
			String lesson11, String lesson12, String lesson13, String lesson14,
			String lesson15, String lesson16, String lesson17, String lesson18,
			String lesson19, String lesson20, String lesson21, String lesson22) {
		super();
		this.id = id;
		this.lesson1 = lesson1;
		this.lesson2 = lesson2;
		this.lesson3 = lesson3;
		this.lesson4 = lesson4;
		this.lesson5 = lesson5;
		this.lesson6 = lesson6;
		this.lesson7 = lesson7;
		this.lesson8 = lesson8;
		this.lesson9 = lesson9;
		this.lesson10 = lesson10;
		this.lesson11 = lesson11;
		this.lesson12 = lesson12;
		this.lesson13 = lesson13;
		this.lesson14 = lesson14;
		this.lesson15 = lesson15;
		this.lesson16 = lesson16;
		this.lesson17 = lesson17;
		this.lesson18 = lesson18;
		this.lesson19 = lesson19;
		this.lesson20 = lesson20;
		this.lesson21 = lesson21;
		this.lesson22 = lesson22;
	}
	public LessonStatusBean() {
		super();
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getLesson1() {
		return lesson1;
	}
	public void setLesson1(String lesson1) {
		this.lesson1 = lesson1;
	}
	public String getLesson2() {
		return lesson2;
	}
	public void setLesson2(String lesson2) {
		this.lesson2 = lesson2;
	}
	public String getLesson3() {
		return lesson3;
	}
	public void setLesson3(String lesson3) {
		this.lesson3 = lesson3;
	}
	public String getLesson4() {
		return lesson4;
	}
	public void setLesson4(String lesson4) {
		this.lesson4 = lesson4;
	}
	public String getLesson5() {
		return lesson5;
	}
	public void setLesson5(String lesson5) {
		this.lesson5 = lesson5;
	}
	public String getLesson6() {
		return lesson6;
	}
	public void setLesson6(String lesson6) {
		this.lesson6 = lesson6;
	}
	public String getLesson7() {
		return lesson7;
	}
	public void setLesson7(String lesson7) {
		this.lesson7 = lesson7;
	}
	public String getLesson8() {
		return lesson8;
	}
	public void setLesson8(String lesson8) {
		this.lesson8 = lesson8;
	}
	public String getLesson9() {
		return lesson9;
	}
	public void setLesson9(String lesson9) {
		this.lesson9 = lesson9;
	}
	public String getLesson10() {
		return lesson10;
	}
	public void setLesson10(String lesson10) {
		this.lesson10 = lesson10;
	}
	public String getLesson11() {
		return lesson11;
	}
	public void setLesson11(String lesson11) {
		this.lesson11 = lesson11;
	}
	public String getLesson12() {
		return lesson12;
	}
	public void setLesson12(String lesson12) {
		this.lesson12 = lesson12;
	}
	public String getLesson13() {
		return lesson13;
	}
	public void setLesson13(String lesson13) {
		this.lesson13 = lesson13;
	}
	public String getLesson14() {
		return lesson14;
	}
	public void setLesson14(String lesson14) {
		this.lesson14 = lesson14;
	}
	public String getLesson15() {
		return lesson15;
	}
	public void setLesson15(String lesson15) {
		this.lesson15 = lesson15;
	}
	public String getLesson16() {
		return lesson16;
	}
	public void setLesson16(String lesson16) {
		this.lesson16 = lesson16;
	}
	public String getLesson17() {
		return lesson17;
	}
	public void setLesson17(String lesson17) {
		this.lesson17 = lesson17;
	}
	public String getLesson18() {
		return lesson18;
	}
	public void setLesson18(String lesson18) {
		this.lesson18 = lesson18;
	}
	public String getLesson19() {
		return lesson19;
	}
	public void setLesson19(String lesson19) {
		this.lesson19 = lesson19;
	}
	public String getLesson20() {
		return lesson20;
	}
	public void setLesson20(String lesson20) {
		this.lesson20 = lesson20;
	}
	public String getLesson21() {
		return lesson21;
	}
	public void setLesson21(String lesson21) {
		this.lesson21 = lesson21;
	}
	public String getLesson22() {
		return lesson22;
	}
	public void setLesson22(String lesson22) {
		this.lesson22 = lesson22;
	}

	
}
