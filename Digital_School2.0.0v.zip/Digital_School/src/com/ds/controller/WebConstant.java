package com.ds.controller;


public interface WebConstant
{
	//游客
	int pub=0;
	//学生
	int stu=1;
	//老师
	int teh=2;
	//管理员
	int adm=3;
}
