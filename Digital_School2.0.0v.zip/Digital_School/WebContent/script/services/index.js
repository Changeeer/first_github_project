//此处需要手动维护
define([
'./myservices'
], function () {});